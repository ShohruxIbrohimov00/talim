/* auth.js – Authentication UI */

const Auth = (() => {

  function showTab(tab) {
    document.getElementById('form-login').style.display    = tab === 'login'    ? 'block' : 'none';
    document.getElementById('form-register').style.display = tab === 'register' ? 'block' : 'none';
    document.getElementById('tab-login').classList.toggle('active',    tab === 'login');
    document.getElementById('tab-register').classList.toggle('active', tab === 'register');
  }

  async function login() {
    const phone = document.getElementById('loginPhone').value.trim();
    const pass  = document.getElementById('loginPass').value;

    if (!phone || !pass) {
      App.toast('Telefon va parolni kiriting!', 'error');
      return;
    }

    try {
      App.setLoading(true);
      const res = await Api.login(phone, pass);
      App.setLoading(false);
      App.toast(`Xush kelibsiz, ${res.user.name}!`, 'success');

      // Update header button
      const btn = document.getElementById('headerAuthBtn');
      if (btn) btn.innerHTML = `👤 ${res.user.name}`;

      App.showPage('page-home');
    } catch(e) {
      App.setLoading(false);
      App.toast(e.message, 'error');
    }
  }

  async function register() {
    const name  = document.getElementById('regName').value.trim();
    const phone = document.getElementById('regPhone').value.trim();
    const pass  = document.getElementById('regPass').value;

    if (!name || !phone || !pass) {
      App.toast("Barcha maydonlarni to'ldiring!", 'error');
      return;
    }
    if (pass.length < 6) {
      App.toast('Parol kamida 6 ta belgi!', 'error');
      return;
    }

    try {
      App.setLoading(true);
      const res = await Api.register(phone, name, pass);
      App.setLoading(false);
      App.toast(`Xush kelibsiz, ${res.user.name}! 14 kunlik sinov boshlandi.`, 'success');

      const btn = document.getElementById('headerAuthBtn');
      if (btn) btn.innerHTML = `👤 ${res.user.name}`;

      App.showPage('page-home');
    } catch(e) {
      App.setLoading(false);
      App.toast(e.message, 'error');
    }
  }

  // Check existing session on load
  async function checkSession() {
    if (!Api.getToken()) return;
    try {
      const user = await Api.me();
      const btn = document.getElementById('headerAuthBtn');
      if (btn && user) btn.innerHTML = `👤 ${user.name}`;
    } catch(e) {
      Api.setToken(null);
    }
  }

  document.addEventListener('DOMContentLoaded', checkSession);

  return { showTab, login, register };
})();
