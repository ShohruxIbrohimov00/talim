"""
SQLAlchemy ORM Models
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database import Base


class Fan(Base):
    __tablename__ = "fanlar"

    id = Column(Integer, primary_key=True, index=True)
    nomi = Column(String(100), unique=True, nullable=False)
    icon = Column(String(10), default="📚")
    rang = Column(String(20), default="#f59e0b")

    mavzular = relationship("Mavzu", back_populates="fan")


class Sinf(Base):
    __tablename__ = "sinflar"

    id = Column(Integer, primary_key=True, index=True)
    raqami = Column(Integer, unique=True, nullable=False)

    mavzular = relationship("Mavzu", back_populates="sinf")


class Mavzu(Base):
    __tablename__ = "mavzular"

    id = Column(Integer, primary_key=True, index=True)
    fan_id = Column(Integer, ForeignKey("fanlar.id"), nullable=False)
    sinf_id = Column(Integer, ForeignKey("sinflar.id"), nullable=False)
    nomi = Column(String(200), nullable=False)

    fan = relationship("Fan", back_populates="mavzular")
    sinf = relationship("Sinf", back_populates="mavzular")
    generated_content = relationship("GeneratedContent", back_populates="mavzu")


class GeneratedContent(Base):
    __tablename__ = "generated_content"

    id = Column(Integer, primary_key=True, index=True)
    mavzu_id = Column(Integer, ForeignKey("mavzular.id"), nullable=False)
    mashq_turi = Column(String(50), nullable=False)
    necha_ta = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)  # JSON string
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    mavzu = relationship("Mavzu", back_populates="generated_content")


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    phone = Column(String(20), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    hashed_password = Column(String(200), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    subscription = relationship("Subscription", back_populates="user", uselist=False)


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    plan = Column(String(20), default="free")  # free, basic, premium
    is_active = Column(Boolean, default=True)
    trial_end = Column(DateTime(timezone=True), nullable=True)
    sub_end = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="subscription")
