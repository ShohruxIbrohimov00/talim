/* app.js – Main Application Controller */

const App = (() => {
  let currentLang = localStorage.getItem('edu_lang') || 'uz';

  // ── Pages ──────────────────────────────────────────────

  function showPage(id) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(id);
    if (page) {
      page.classList.add('active');
      window.scrollTo(0, 0);
    }
  }

  // ── Language ───────────────────────────────────────────

  function setLang(lang) {
    currentLang = lang;
    localStorage.setItem('edu_lang', lang);
    document.documentElement.lang = lang;

    // Update lang buttons
    document.querySelectorAll('.lang-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.lang === lang);
    });

    // Apply all translations
    applyTranslations();

    // Re-render setup if on setup page
    if (document.getElementById('page-setup').classList.contains('active')) {
      Setup.renderFanlar();
      Setup.renderMashqlar();
    }
  }

  function applyTranslations() {
    const dict = I18N[currentLang] || I18N.uz;
    Object.entries(dict).forEach(([key, val]) => {
      const el = document.getElementById(key);
      if (el) el.textContent = val;
    });

    // Placeholders
    const mavzuInput = document.getElementById('mavzuInput');
    if (mavzuInput) mavzuInput.placeholder = t('fill-placeholder');

    const timerOff = document.getElementById('tb0');
    if (timerOff) timerOff.textContent = t('timer-off-label');

    // Screen alert
    const alertTitle = document.querySelector('.screen-alert-inner h2');
    const alertDesc  = document.querySelector('.screen-alert-inner p');
    if (alertTitle) alertTitle.textContent = t('alert-title');
    if (alertDesc)  alertDesc.textContent  = t('alert-desc');
  }

  // ── Toast ──────────────────────────────────────────────

  let toastTimer;
  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = `toast ${type} show`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  // ── Loading ────────────────────────────────────────────

  function setLoading(show, msg = null) {
    const overlay = document.getElementById('loadingOverlay');
    const text    = document.getElementById('loadingText');
    overlay.classList.toggle('active', show);
    if (text) text.innerHTML = (msg || t('loading-text')) + '<span class="dots"></span>';
  }

  // ── Konfetti ───────────────────────────────────────────

  function konfetti() {
    const canvas = document.getElementById('konfetti');
    canvas.style.display = 'block';
    const ctx = canvas.getContext('2d');
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;

    const colors = ['#f59e0b','#3b82f6','#10b981','#ef4444','#8b5cf6','#f97316'];
    const particles = Array.from({ length: 140 }, () => ({
      x: Math.random() * canvas.width,
      y: -20,
      w: Math.random() * 12 + 5,
      h: Math.random() * 6 + 3,
      color: colors[Math.floor(Math.random() * colors.length)],
      vx: (Math.random() - 0.5) * 5,
      vy: Math.random() * 3 + 2,
      rot: Math.random() * 360,
      rotV: (Math.random() - 0.5) * 8,
      gravity: 0.06 + Math.random() * 0.04
    }));

    let frame = 0;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot * Math.PI / 180);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        ctx.restore();
        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.gravity;
        p.rot += p.rotV;
        p.vx *= 0.99;
      });
      frame++;
      if (frame < 200) requestAnimationFrame(animate);
      else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.style.display = 'none';
      }
    };
    animate();
  }

  // ── Init ───────────────────────────────────────────────

  async function init() {
    setLang(currentLang);
    await Setup.init();
  }

  // Start when DOM ready
  document.addEventListener('DOMContentLoaded', init);

  return { showPage, setLang, toast, setLoading, konfetti, currentLang: null };
})();

// Make currentLang accessible as a getter
Object.defineProperty(App, 'currentLang', {
  get() { return localStorage.getItem('edu_lang') || 'uz'; }
});
