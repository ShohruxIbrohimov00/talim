/* setup.js – Setup page controller */

const Setup = (() => {
  let fanlar = [];
  let sinflar = [];
  let mavzular = [];

  let selectedFan = null;
  let selectedSinf = null;
  let selectedMavzu = '';
  let selectedMashqlar = new Set();
  let questionCount = 10;

  const MASHQ_META = [
    { type: 'quiz',       icon: '📊', nameKey: 'Quiz',           descKey: '4 variantli test' },
    { type: 'truefalse',  icon: '✅', nameKey: "To'g'ri/Noto'g'ri", descKey: 'True/False savollari' },
    { type: 'fill',       icon: '✏️', nameKey: "Bo'shliq To'ldirish", descKey: 'Javobni yozing' },
    { type: 'wordsearch', icon: '🔍', nameKey: "So'z Qidirish",   descKey: 'Jadvaldan toping' },
    { type: 'riddle',     icon: '🧩', nameKey: 'Boshqotirma',     descKey: 'Topishmoqlar' },
    { type: 'matching',   icon: '🔗', nameKey: 'Moslashtirish',   descKey: 'Juftlashtiruv' },
  ];

  const MASHQ_NAMES = {
    uz: ["Quiz","To'g'ri/Noto'g'ri","Bo'shliq To'ldirish","So'z Qidirish","Boshqotirma","Moslashtirish"],
    ru: ["Тест","Верно/Неверно","Заполни пропуск","Поиск слов","Головоломка","Сопоставление"],
    en: ["Quiz","True/False","Fill the Blank","Word Search","Riddle","Matching"]
  };
  const MASHQ_DESCS = {
    uz: ["4 variantli test","True/False savollari","Javobni yozing","Jadvaldan so'z toping","Topishmoqlar","Juftlashtiruv"],
    ru: ["Тест с 4 вариантами","Верно/Неверно вопросы","Напишите ответ","Найдите слово","Загадки","Сопоставление"],
    en: ["4-option test","True/False questions","Write the answer","Find words in grid","Riddles","Pair matching"]
  };

  // ── Init ──────────────────────────────────────────────

  async function init() {
    try {
      [fanlar, sinflar] = await Promise.all([
        Api.getFanlar(),
        Api.getSinflar()
      ]);
    } catch(e) {
      // Use fallback data
      fanlar = [
        {id:1, nomi:'Matematika',  icon:'🔢', rang:'#f59e0b'},
        {id:2, nomi:"O'zbek tili", icon:'📝', rang:'#10b981'},
        {id:3, nomi:'Ingliz tili', icon:'🌍', rang:'#3b82f6'},
        {id:4, nomi:'Geografiya',  icon:'🗺️', rang:'#8b5cf6'},
        {id:5, nomi:'Tarix',       icon:'📜', rang:'#ef4444'},
        {id:6, nomi:'Fizika',      icon:'⚡', rang:'#f97316'},
        {id:7, nomi:'Kimyo',       icon:'🧪', rang:'#06b6d4'},
        {id:8, nomi:'Biologiya',   icon:'🌿', rang:'#84cc16'},
        {id:9, nomi:'Boshqa',      icon:'📖', rang:'#94a3b8'},
      ];
      sinflar = Array.from({length:11}, (_,i) => ({id:i+1, raqami:i+1}));
    }

    renderFanlar();
    renderSinflar();
    renderMashqlar();
  }

  // ── Render Fanlar ─────────────────────────────────────

  function renderFanlar() {
    const grid = document.getElementById('fanGrid');
    if (!grid) return;
    const lang = App.currentLang;

    const fanNamesLocal = {
      uz: ['Matematika',"O'zbek tili",'Ingliz tili','Geografiya','Tarix','Fizika','Kimyo','Biologiya','Boshqa'],
      ru: ['Математика','Узб. язык','Английский','География','История','Физика','Химия','Биология','Другое'],
      en: ['Mathematics','Uzbek','English','Geography','History','Physics','Chemistry','Biology','Other']
    };

    grid.innerHTML = fanlar.map((fan, i) => {
      const name = fanNamesLocal[lang]?.[i] || fan.nomi;
      const sel = selectedFan?.id === fan.id;
      return `
        <div class="fan-card ${sel ? 'selected' : ''}"
             onclick="Setup.selectFan(${fan.id})"
             data-fan-id="${fan.id}">
          <span class="fan-icon">${fan.icon}</span>
          <span>${name}</span>
        </div>
      `;
    }).join('');
  }

  // ── Render Sinflar ────────────────────────────────────

  function renderSinflar() {
    const grid = document.getElementById('sinfGrid');
    if (!grid) return;
    grid.innerHTML = sinflar.map(s => `
      <button class="sinf-btn ${selectedSinf?.id === s.id ? 'selected' : ''}"
              onclick="Setup.selectSinf(${s.id})"
              data-sinf-id="${s.id}">${s.raqami}</button>
    `).join('');
  }

  // ── Render Mashqlar ───────────────────────────────────

  function renderMashqlar() {
    const grid = document.getElementById('mashqGrid');
    if (!grid) return;
    const lang = App.currentLang;
    const names = MASHQ_NAMES[lang] || MASHQ_NAMES.uz;
    const descs = MASHQ_DESCS[lang] || MASHQ_DESCS.uz;

    grid.innerHTML = MASHQ_META.map((m, i) => {
      const sel = selectedMashqlar.has(m.type);
      return `
        <div class="mashq-card ${sel ? 'selected' : ''}"
             onclick="Setup.toggleMashq('${m.type}', this)"
             data-type="${m.type}">
          <div class="mashq-checkbox">${sel ? '✓' : ''}</div>
          <span class="mashq-body-icon">${m.icon}</span>
          <div class="mashq-body">
            <div class="mashq-name">${names[i]}</div>
            <div class="mashq-desc">${descs[i]}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  // ── Select Fan ────────────────────────────────────────

  async function selectFan(fanId) {
    selectedFan = fanlar.find(f => f.id === fanId) || null;
    renderFanlar();
    await loadMavzular();
  }

  // ── Select Sinf ───────────────────────────────────────

  async function selectSinf(sinfId) {
    selectedSinf = sinflar.find(s => s.id === sinfId) || null;
    renderSinflar();
    await loadMavzular();
  }

  // ── Load Mavzular ─────────────────────────────────────

  async function loadMavzular() {
    if (!selectedFan || !selectedSinf) return;
    try {
      mavzular = await Api.getMavzular(selectedFan.id, selectedSinf.id);
    } catch(e) {
      mavzular = getFallbackMavzular(selectedFan.nomi, selectedSinf.raqami);
    }
    renderMavzuTags();
  }

  function getFallbackMavzular(fanNomi, sinfRaqami) {
    const map = {
      'Matematika': {5:['Butun sonlar','Kasrlar','Foizlar'],6:['Kasrlar','Nisbat','Tengsizliklar'],7:['Tenglamalar',"Ko'paytirish formulalari",'Uchburchaklar'],8:['Kvadrat tenglamalar','Funksiyalar','Vektorlar'],9:['Progressiya','Logarifm','Trigonometriya']},
      "O'zbek tili": {5:["So'z turkumlari",'Ot','Sifat'],6:["Gapning bo'laklari",'Murakkab gap'],7:["So'z yasalishi",'Imlo qoidalari']},
      'Ingliz tili': {5:['Present Simple','Family','Animals'],6:['Past Simple','Prepositions'],7:['Present Perfect','Modal verbs'],8:['Conditionals','Passive voice']},
      'Fizika': {7:['Mexanik harakat','Kuch','Bosim'],8:['Elektr toki','Optika'],9:['Mexanika','Termodinamika']},
      'Kimyo': {8:['Atom tuzilishi','Kislotalar'],9:['Organik kimyo','Uglevodorodlar']},
      'Biologiya': {6:["O'simlik hujayra",'Fotosintez'],7:['Qon aylanishi','Asab tizimi'],8:['Genetika','Evolutsiya']},
    };
    const fanData = map[fanNomi];
    if (!fanData) return [{id:-1, nomi: fanNomi + ' - umumiy mavzu'}];
    const sinfData = fanData[sinfRaqami] || fanData[Object.keys(fanData)[0]] || [];
    return sinfData.map((nomi, i) => ({id: -(i+1), nomi}));
  }

  function renderMavzuTags() {
    const container = document.getElementById('mavzuTags');
    if (!container) return;
    container.innerHTML = mavzular.map(m => `
      <div class="tag ${selectedMavzu === m.nomi ? 'selected' : ''}"
           onclick="Setup.pickMavzu('${m.nomi.replace(/'/g,"\\'")}', this)">
        ${m.nomi}
      </div>
    `).join('');
  }

  function pickMavzu(nomi, el) {
    selectedMavzu = nomi;
    document.getElementById('mavzuInput').value = nomi;
    document.querySelectorAll('#mavzuTags .tag').forEach(t => t.classList.remove('selected'));
    if (el) el.classList.add('selected');
  }

  function onMavzuInput(val) {
    selectedMavzu = val;
    document.querySelectorAll('#mavzuTags .tag').forEach(t => t.classList.remove('selected'));
  }

  // ── Toggle Mashq ──────────────────────────────────────

  function toggleMashq(type, el) {
    if (selectedMashqlar.has(type)) {
      selectedMashqlar.delete(type);
      el.classList.remove('selected');
      el.querySelector('.mashq-checkbox').textContent = '';
    } else {
      selectedMashqlar.add(type);
      el.classList.add('selected');
      el.querySelector('.mashq-checkbox').textContent = '✓';
    }
  }

  // ── Count stepper ─────────────────────────────────────

  function changeCount(delta) {
    questionCount = Math.max(3, Math.min(30, questionCount + delta));
    document.getElementById('stepperVal').textContent = questionCount;
  }

  // ── Generate ──────────────────────────────────────────

  async function generate() {
    // Validations
    if (!selectedFan)            { App.toast(t('toast-no-fan'),   'error'); return; }
    if (!selectedSinf)           { App.toast(t('toast-no-sinf'),  'error'); return; }
    if (!selectedMavzu.trim())   { App.toast(t('toast-no-mavzu'), 'error'); return; }
    if (!selectedMashqlar.size)  { App.toast(t('toast-no-mashq'), 'error'); return; }

    App.setLoading(true);

    try {
      // Get or create mavzu
      let mavzuId;
      try {
        const existing = mavzular.find(m => m.nomi === selectedMavzu);
        if (existing && existing.id > 0) {
          mavzuId = existing.id;
        } else {
          const created = await Api.createMavzu(selectedFan.id, selectedSinf.id, selectedMavzu);
          mavzuId = created.id;
        }
      } catch(e) {
        mavzuId = 1; // fallback
      }

      const apiKey = document.getElementById('apiKeyInput')?.value?.trim() || '';

      const res = await Api.generate({
        mavzu_id: mavzuId,
        mavzu_nomi: selectedMavzu,
        fan_nomi: selectedFan.nomi,
        sinf_raqami: selectedSinf.raqami,
        mashq_turlari: [...selectedMashqlar],
        necha_ta: questionCount,
        api_key: apiKey || null
      });

      // Store results in Exercise state
      Exercise.setData({
        content: res.data,
        fan: selectedFan,
        sinf: selectedSinf,
        mavzu: selectedMavzu
      });

      App.setLoading(false);
      App.toast(t('toast-ready'), 'success');
      renderResults(res.data);
      App.showPage('page-results');

    } catch(e) {
      App.setLoading(false);
      App.toast(e.message || 'Xato yuz berdi', 'error');
    }
  }

  // ── Render Results ────────────────────────────────────

  const TYPE_META = {
    quiz:       { icon: '📊', color: '#f59e0b' },
    truefalse:  { icon: '✅', color: '#3b82f6' },
    fill:       { icon: '✏️', color: '#10b981' },
    wordsearch: { icon: '🔍', color: '#8b5cf6' },
    riddle:     { icon: '🧩', color: '#ef4444' },
    matching:   { icon: '🔗', color: '#06b6d4' },
  };

  function renderResults(data) {
    const lang = App.currentLang;
    const names = MASHQ_NAMES[lang] || MASHQ_NAMES.uz;
    const grid = document.getElementById('resultsGrid');
    if (!grid) return;

    grid.innerHTML = Object.entries(data).map(([type, items]) => {
      const meta  = TYPE_META[type] || { icon: '📋', color: '#f59e0b' };
      const idx   = MASHQ_META.findIndex(m => m.type === type);
      const name  = names[idx] ?? type;
      const count = Array.isArray(items) ? items.length : 1;

      return `
        <div class="result-card" style="--rc-color:${meta.color}">
          <span class="rc-icon">${meta.icon}</span>
          <div class="rc-title">${name}</div>
          <div class="rc-count">${count} ta mashq</div>
          <button class="rc-btn" onclick="Exercise.start('${type}')">
            ▶ ${t('start-btn')}
          </button>
        </div>
      `;
    }).join('');
  }

  return {
    init,
    renderFanlar,
    renderMashqlar,
    selectFan,
    selectSinf,
    toggleMashq,
    changeCount,
    generate,
    pickMavzu,
    onMavzuInput
  };
})();
