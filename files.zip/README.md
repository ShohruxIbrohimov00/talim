# ⚡ EduBoard Interactive

> O'qituvchilar uchun AI yordamida interaktiv dars o'tkazish platformasi
> Elektron doska (1280px+) uchun optimallashtirilgan

---

## 🗂️ Loyiha tuzilmasi

```
eduboard/
├── backend/
│   ├── main.py              # FastAPI asosiy app
│   ├── database.py          # SQLAlchemy connection
│   ├── models.py            # ORM modellari
│   ├── schemas.py           # Pydantic schemas
│   ├── seed_data.py         # Boshlang'ich ma'lumotlar
│   ├── services/
│   │   ├── ai_service.py    # OpenAI + namunaviy content
│   │   └── auth_service.py  # JWT autentifikatsiya
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── templates/
│   │   └── index.html       # Asosiy HTML (Jinja2)
│   └── static/
│       ├── css/
│       │   └── main.css     # Barcha stillar
│       └── js/
│           ├── i18n.js      # 3 til: O'ZB, RUS, ENG
│           ├── audio.js     # Web Audio API ovoz effektlari
│           ├── api.js       # Backend bilan muloqot
│           ├── app.js       # Asosiy kontroller
│           ├── setup.js     # Sozlamalar sahifasi
│           ├── exercise.js  # Mashq o'tkazish
│           └── auth.js      # Login / Ro'yxat
├── docker-compose.yml
└── README.md
```

---

## 🚀 Ishga tushirish

### Usul 1 – Docker bilan (tavsiya)

```bash
# 1. Klonlash
git clone <repo-url>
cd eduboard

# 2. Ishga tushirish
docker-compose up -d

# 3. Brauzerda oching
# http://localhost:8000
```

---

### Usul 2 – Qo'lda (lokal)

#### Backend

```bash
cd backend

# Virtual muhit
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# Kutubxonalar
pip install -r requirements.txt

# SQLite bilan ishga tushirish (test uchun)
uvicorn main:app --reload --port 8000
```

#### Brauzer
```
http://localhost:8000
```

---

### Usul 3 – PostgreSQL bilan

```bash
# .env fayl yarating
DATABASE_URL=postgresql://user:password@localhost:5432/eduboard
SECRET_KEY=your-secret-key-here

# Yoki to'g'ridan-to'g'ri
export DATABASE_URL="postgresql://user:password@localhost:5432/eduboard"
uvicorn main:app --reload
```

---

## ⚙️ Sozlamalar

### OpenAI API Key
Interfeysdagi "OpenAI API Key" maydoniga kiriting. Key bo'lmasa avtomatik namunaviy savollar ishlatiladi.

### To'g'ri ishlash uchun ekran o'lchami
- **Minimal**: 1024px kenglik
- **Optimal**: 1280px–1920px (elektron doska)
- Kichik ekranlarda ogohlantirish ko'rsatiladi

---

## 🎮 Mashq turlari

| Tur | Tavsif |
|-----|--------|
| 📊 Quiz | 4 variantli multiple choice |
| ✅ True/False | To'g'ri/Noto'g'ri |
| ✏️ Fill Blank | Bo'shliqni to'ldirish |
| 🔍 Word Search | So'z qidirish jadval |
| 🧩 Riddle | Boshqotirma / Topishmoq |
| 🔗 Matching | Juftlashtiruv |

---

## 🌐 3 Til

- 🇺🇿 O'zbek (asosiy)
- 🇷🇺 Rus
- 🇬🇧 Ingliz

---

## 📡 API Endpointlar

```
GET  /api/fanlar                     → Fanlar ro'yxati
GET  /api/sinflar                    → Sinflar (1-11)
GET  /api/mavzular?fan_id=&sinf_id=  → Mavzular
POST /api/mavzular                   → Yangi mavzu qo'shish
POST /api/generate                   → Savollar generatsiya
POST /api/auth/register              → Ro'yxatdan o'tish
POST /api/auth/login                 → Kirish
GET  /api/auth/me                    → Joriy foydalanuvchi
GET  /api/health                     → Server holati
GET  /docs                           → Swagger UI
```

---

## 💳 To'lov tizimi (kelajak)

```
Bepul sinov:  14 kun
Asosiy:       50 000 so'm/oy
Premium:      100 000 so'm/oy
```
Click/Payme integratsiyasi qo'shish uchun `backend/services/payment_service.py` fayli yarating.

---

## 📝 Litsenziya

MIT © EduBoard 2024
