/* exercise.js – Exercise controller */

const Exercise = (() => {

  // ── State ──────────────────────────────────────────────
  let _data = {};
  let _fan  = null;
  let _sinf = null;
  let _mavzu = '';

  let currentType  = null;
  let questions    = [];
  let currentIndex = 0;
  let score        = 0;
  let answered     = {};   // index → answer

  // Timer state
  let timerSecs    = 60;
  let timerActive  = true;
  let timerLeft    = 60;
  let timerInterval = null;

  // Word-search state
  let wsSelected   = [];
  let wsFound      = [];   // words found

  // ── Public API ─────────────────────────────────────────

  function setData({ content, fan, sinf, mavzu }) {
    _data  = content;
    _fan   = fan;
    _sinf  = sinf;
    _mavzu = mavzu;
  }

  function start(type) {
    currentType  = type;
    questions    = _data[type] || [];
    currentIndex = 0;
    score        = 0;
    answered     = {};
    wsSelected   = [];
    wsFound      = [];

    if (!questions.length) {
      App.toast('Bu turdagi mashq topilmadi', 'error');
      return;
    }

    // Sidebar info
    document.getElementById('sbSubject').textContent = _fan?.nomi || '—';
    document.getElementById('sbTopic').textContent   = _mavzu || '—';

    // Type chip
    const TYPE_ICONS = {quiz:'📊',truefalse:'✅',fill:'✏️',wordsearch:'🔍',riddle:'🧩',matching:'🔗'};
    const MASHQ_NAMES = {
      uz: {quiz:"Quiz",truefalse:"To'g'ri/Noto'g'ri",fill:"Bo'shliq",wordsearch:"So'z Qidirish",riddle:"Boshqotirma",matching:"Moslashtirish"},
      ru: {quiz:"Тест",truefalse:"Верно/Неверно",fill:"Пропуск",wordsearch:"Поиск слов",riddle:"Головоломка",matching:"Сопоставление"},
      en: {quiz:"Quiz",truefalse:"True/False",fill:"Fill Blank",wordsearch:"Word Search",riddle:"Riddle",matching:"Matching"},
    };
    const lang = App.currentLang;
    const name = MASHQ_NAMES[lang]?.[type] || type;
    document.getElementById('exTypeChip').textContent = `${TYPE_ICONS[type] || '📋'} ${name}`;

    updateSidebar();
    renderQuestion();
    startTimer();
    App.showPage('page-exercise');
  }

  // ── Sidebar ────────────────────────────────────────────

  function updateSidebar() {
    const n = questions.length;
    const pct = n ? Math.round(((currentIndex) / n) * 100) : 0;

    document.getElementById('progressFill').style.width = pct + '%';
    document.getElementById('pCurrent').textContent = currentIndex + 1;
    document.getElementById('pTotal').textContent   = n;
    document.getElementById('scoreNum').textContent = score;
    document.getElementById('scoreSub').textContent = `/ ${n} ${t('t-correct') || "to'g'ri"}`;

    // Q dots
    const list = document.getElementById('qMiniList');
    if (list) {
      list.innerHTML = questions.map((_, i) => {
        let cls = '';
        if (i === currentIndex) cls = 'current';
        else if (answered[i] !== undefined) {
          cls = isAnswerCorrect(i) ? 'correct' : 'wrong';
        }
        return `<div class="q-dot ${cls}" onclick="Exercise.jump(${i})">${i + 1}</div>`;
      }).join('');
    }
  }

  function isAnswerCorrect(i) {
    const q = questions[i];
    const a = answered[i];
    if (a === undefined) return false;
    if (currentType === 'quiz')      return a === q.togri_index;
    if (currentType === 'truefalse') return a === q.javob;
    if (currentType === 'fill')      return a?.toLowerCase() === q.javob?.toLowerCase();
    if (currentType === 'riddle')    return a === true;
    if (currentType === 'matching')  return a === true;
    return false;
  }

  // ── Render Question ───────────────────────────────────

  function renderQuestion() {
    const q = questions[currentIndex];
    const content = document.getElementById('exContent');
    if (!content || !q) return;

    updateSidebar();

    const card = document.createElement('div');
    card.className = 'ex-card';

    const qNum = `<div class="q-num">${t('q-label')} ${currentIndex + 1} / ${questions.length}</div>`;

    switch(currentType) {
      case 'quiz':       card.innerHTML = qNum + renderQuiz(q); break;
      case 'truefalse':  card.innerHTML = qNum + renderTF(q); break;
      case 'fill':       card.innerHTML = qNum + renderFill(q); break;
      case 'wordsearch': card.innerHTML = qNum + renderWordSearch(q); break;
      case 'riddle':     card.innerHTML = qNum + renderRiddle(q); break;
      case 'matching':   card.innerHTML = qNum + renderMatching(q); break;
      default:           card.innerHTML = `<p>${JSON.stringify(q)}</p>`;
    }

    content.innerHTML = '';
    content.appendChild(card);

    // Attach listeners after render
    if (currentType === 'fill') attachFillListeners(q);
  }

  // ── QUIZ ──────────────────────────────────────────────

  function renderQuiz(q) {
    const letters = ['A','B','C','D'];
    const ans = answered[currentIndex];
    const disabled = ans !== undefined;

    const opts = q.variantlar.map((v, i) => {
      let cls = '';
      if (disabled) {
        if (i === q.togri_index) cls = 'correct';
        else if (i === ans)      cls = 'wrong';
      }
      return `
        <button class="opt-btn ${cls}"
          ${disabled ? 'disabled' : `onclick="Exercise.answerQuiz(${i})"`}>
          <span class="opt-letter">${letters[i]}</span>
          <span class="opt-text">${v}</span>
        </button>`;
    }).join('');

    return `
      <div class="q-text">${q.savol}</div>
      <div class="options-grid">${opts}</div>
      ${disabled ? renderFeedback(ans === q.togri_index, q.variantlar[q.togri_index]) : ''}
    `;
  }

  function answerQuiz(idx) {
    if (answered[currentIndex] !== undefined) return;
    const q = questions[currentIndex];
    answered[currentIndex] = idx;
    const correct = idx === q.togri_index;
    if (correct) { score++; Audio.correct(); } else { Audio.wrong(); }
    updateSidebar();
    renderQuestion();
  }

  // ── TRUE / FALSE ──────────────────────────────────────

  function renderTF(q) {
    const ans = answered[currentIndex];
    const disabled = ans !== undefined;

    const trueClass  = disabled ? (q.javob === true  ? 'correct' : (ans === true  ? 'wrong' : '')) : '';
    const falseClass = disabled ? (q.javob === false ? 'correct' : (ans === false ? 'wrong' : '')) : '';

    return `
      <div class="q-text">${q.savol}</div>
      <div class="tf-grid">
        <button class="tf-btn t-btn ${trueClass}"
          ${disabled ? 'disabled' : 'onclick="Exercise.answerTF(true)"'}>
          <span class="tf-icon">✅</span>
          <span class="tf-label">${t('true-text')}</span>
        </button>
        <button class="tf-btn f-btn ${falseClass}"
          ${disabled ? 'disabled' : 'onclick="Exercise.answerTF(false)"'}>
          <span class="tf-icon">❌</span>
          <span class="tf-label">${t('false-text')}</span>
        </button>
      </div>
      ${disabled ? renderFeedback(ans === q.javob, q.javob ? t('true-text') : t('false-text')) : ''}
    `;
  }

  function answerTF(val) {
    if (answered[currentIndex] !== undefined) return;
    const q = questions[currentIndex];
    answered[currentIndex] = val;
    const correct = val === q.javob;
    if (correct) { score++; Audio.correct(); } else { Audio.wrong(); }
    updateSidebar();
    renderQuestion();
  }

  // ── FILL ──────────────────────────────────────────────

  function renderFill(q) {
    const ans = answered[currentIndex];
    const disabled = ans !== undefined;
    const cls = disabled ? (ans?.toLowerCase() === q.javob?.toLowerCase() ? 'correct' : 'wrong') : '';

    return `
      <div class="q-text">${q.savol}</div>
      <div class="fill-wrap">
        <input
          class="fill-input ${cls}"
          id="fillInput"
          type="text"
          placeholder="${t('fill-placeholder')}"
          value="${disabled ? ans : ''}"
          ${disabled ? 'disabled' : ''}
          autocomplete="off"
        >
        <button class="btn-check" id="checkBtn" ${disabled ? 'disabled' : ''} onclick="Exercise.checkFill()">
          ${t('check-btn')}
        </button>
        ${disabled ? renderFeedback(ans?.toLowerCase() === q.javob?.toLowerCase(), q.javob) : ''}
      </div>
    `;
  }

  function attachFillListeners(q) {
    const input = document.getElementById('fillInput');
    if (input && answered[currentIndex] === undefined) {
      input.focus();
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') checkFill();
      });
    }
  }

  function checkFill() {
    if (answered[currentIndex] !== undefined) return;
    const input = document.getElementById('fillInput');
    if (!input) return;
    const val = input.value.trim();
    if (!val) return;
    const q = questions[currentIndex];
    answered[currentIndex] = val;
    const correct = val.toLowerCase() === q.javob.toLowerCase();
    if (correct) { score++; Audio.correct(); } else { Audio.wrong(); }
    updateSidebar();
    renderQuestion();
  }

  // ── WORD SEARCH ───────────────────────────────────────

  function renderWordSearch(q) {
    const rows = q.jadval;
    const cols = rows[0]?.length || 0;

    const cells = rows.map((row, ri) =>
      row.map((cell, ci) => {
        const isSel   = wsSelected.some(([r,c]) => r===ri && c===ci);
        const isFound = isFoundCell(ri, ci, q);
        return `<div class="ws-cell ${isFound?'found':isSel?'sel':''}"
                     onclick="Exercise.toggleWS(${ri},${ci})">${cell}</div>`;
      }).join('')
    ).join('');

    const words = q.sozlar.map(w =>
      `<div class="ws-word ${wsFound.includes(w)?'found':''}">${w}</div>`
    ).join('');

    const foundCount = wsFound.length;
    const total      = q.sozlar.length;

    return `
      <div class="ws-wrap">
        <div class="ws-grid-wrap">
          <div class="ws-grid" style="grid-template-columns:repeat(${cols},42px)">
            ${cells}
          </div>
        </div>
        <div class="ws-words">
          <div class="ws-words-label">${t('words-label')}</div>
          <div class="ws-words-list">${words}</div>
          <div class="ws-score">${foundCount} / ${total} ${t('words-found')}</div>
        </div>
      </div>
    `;
  }

  function isFoundCell(ri, ci, q) {
    // Check if any found word starts here horizontally
    return wsFound.some(w => {
      for (let j = 0; j < w.length; j++) {
        if ((q.jadval[ri]?.[ci+j] || '') !== w[j]) return false;
      }
      return true;
    });
  }

  function toggleWS(ri, ci) {
    const idx = wsSelected.findIndex(([r,c]) => r===ri && c===ci);
    if (idx >= 0) wsSelected.splice(idx, 1);
    else wsSelected.push([ri, ci]);
    checkWSWord();
    renderQuestion();
  }

  function checkWSWord() {
    const q = questions[currentIndex];
    if (!q) return;
    // Try to form word from selected cells (consecutive horizontal)
    const sorted = [...wsSelected].sort((a,b) => a[0]-b[0] || a[1]-b[1]);
    if (!sorted.length) return;
    const row = sorted[0][0];
    if (!sorted.every(([r]) => r === row)) return;
    const word = sorted.map(([r,c]) => q.jadval[r]?.[c] || '').join('');
    if (q.sozlar.includes(word) && !wsFound.includes(word)) {
      wsFound.push(word);
      wsSelected = [];
      Audio.correct();
      score++;
      if (wsFound.length === q.sozlar.length) {
        answered[currentIndex] = true;
      }
      updateSidebar();
    }
  }

  // ── RIDDLE ────────────────────────────────────────────

  function renderRiddle(q) {
    const revealed = answered[currentIndex] !== undefined;
    return `
      <div class="riddle-wrap">
        <span class="riddle-emoji">🧩</span>
        <div class="riddle-text">${q.savol}</div>
        ${revealed
          ? `<div class="riddle-answer show">
               <div class="riddle-ans-label">${t('answer-label')}</div>
               <div class="riddle-ans-text">${q.javob}</div>
             </div>`
          : `<button class="btn-reveal" onclick="Exercise.revealRiddle()">
               ${t('reveal-btn')}
             </button>
             <div class="riddle-answer" id="riddleAns">
               <div class="riddle-ans-label">${t('answer-label')}</div>
               <div class="riddle-ans-text">${q.javob}</div>
             </div>`
        }
      </div>
    `;
  }

  function revealRiddle() {
    const ansEl = document.getElementById('riddleAns');
    if (ansEl) ansEl.classList.add('show');
    Audio.reveal();
    if (answered[currentIndex] === undefined) {
      answered[currentIndex] = true;
      score++;
      updateSidebar();
    }
    renderQuestion();
  }

  // ── MATCHING ──────────────────────────────────────────

  function renderMatching(q) {
    const shuffled = [...q.juftlar].sort(() => Math.random() - 0.5);
    const revealed = answered[currentIndex] !== undefined;

    const leftItems  = q.juftlar.map(j => `<div class="match-item">${j.chap}</div>`).join('');
    const rightItems = shuffled.map(j  => `<div class="match-item" onclick="this.style.outline='2px solid var(--gold)'">${j.ong}</div>`).join('');
    const arrows     = q.juftlar.map(() => `<div class="arrow-icon">→</div>`).join('');

    return `
      <div class="matching-wrap">
        <div class="q-text">${q.sarlavha}</div>
        <div class="matching-grid">
          <div class="match-left">${leftItems}</div>
          <div class="match-arrows">${arrows}</div>
          <div class="match-right">${rightItems}</div>
        </div>
        ${revealed
          ? renderMatchAnswer(q.juftlar)
          : `<button class="btn-check" onclick="Exercise.revealMatching()">
               ${t('reveal-btn')}
             </button>
             <div class="match-answer-wrap" id="matchAns">
               ${renderMatchAnswer(q.juftlar)}
             </div>`
        }
      </div>
    `;
  }

  function renderMatchAnswer(juftlar) {
    return `<div class="match-answer-wrap show">
      ${juftlar.map(j => `
        <div class="match-pair">
          <span>${j.chap}</span>
          <span class="match-arrow-small">→</span>
          <span style="color:var(--green)">${j.ong}</span>
        </div>
      `).join('')}
    </div>`;
  }

  function revealMatching() {
    const el = document.getElementById('matchAns');
    if (el) el.classList.add('show');
    Audio.reveal();
    if (answered[currentIndex] === undefined) {
      answered[currentIndex] = true;
      score++;
      updateSidebar();
    }
    renderQuestion();
  }

  // ── Feedback ──────────────────────────────────────────

  function renderFeedback(correct, correctAnswer) {
    return `
      <div class="feedback ${correct ? 'correct' : 'wrong'}">
        <span class="fb-icon">${correct ? '🎉' : '😔'}</span>
        <div class="fb-main">
          <div class="fb-title">${t(correct ? 'correct-text' : 'wrong-text')}</div>
          ${!correct ? `<div class="fb-answer">${t('answer-label')} <strong>${correctAnswer}</strong></div>` : ''}
        </div>
      </div>
    `;
  }

  // ── Navigation ────────────────────────────────────────

  function next() {
    if (currentIndex < questions.length - 1) {
      currentIndex++;
      wsSelected = [];
      renderQuestion();
      resetTimer();
    } else {
      showSummary();
    }
  }

  function prev() {
    if (currentIndex > 0) {
      currentIndex--;
      wsSelected = [];
      renderQuestion();
      resetTimer();
    }
  }

  function jump(i) {
    currentIndex = i;
    wsSelected = [];
    renderQuestion();
    resetTimer();
  }

  // ── Summary ───────────────────────────────────────────

  function showSummary() {
    clearInterval(timerInterval);
    const total   = questions.length;
    const correct = score;
    const wrong   = total - correct;
    const pct     = total ? Math.round((correct / total) * 100) : 0;

    document.getElementById('sumCorrect').textContent = correct;
    document.getElementById('sumWrong').textContent   = wrong;
    document.getElementById('sumPct').textContent     = pct + '%';

    let emoji, titleKey;
    if (pct >= 90)      { emoji = '🏆'; titleKey = 'sum-perfect'; }
    else if (pct >= 70) { emoji = '👏'; titleKey = 'sum-good'; }
    else if (pct >= 50) { emoji = '👍'; titleKey = 'sum-ok'; }
    else                { emoji = '💪'; titleKey = 'sum-try'; }

    document.getElementById('sumEmoji').textContent = emoji;
    document.getElementById('sumTitle').textContent = t(titleKey);
    document.getElementById('sumSub').textContent   = `${total} ${t('sum-sub')}`;

    if (pct >= 70) App.konfetti();
    App.showPage('page-summary');
  }

  // ── Timer ─────────────────────────────────────────────

  function setTimer(secs) {
    timerSecs   = secs;
    timerActive = secs > 0;
    ['tb30','tb60','tb0'].forEach(id => {
      document.getElementById(id)?.classList.remove('active');
    });
    if (secs === 30) document.getElementById('tb30')?.classList.add('active');
    else if (secs === 60) document.getElementById('tb60')?.classList.add('active');
    else document.getElementById('tb0')?.classList.add('active');
    resetTimer();
  }

  function startTimer() {
    clearInterval(timerInterval);
    const el = document.getElementById('timerVal');
    if (!timerActive || timerSecs === 0) {
      if (el) { el.textContent = '∞'; el.classList.remove('warning'); }
      return;
    }
    timerLeft = timerSecs;
    if (el) el.textContent = timerLeft;

    timerInterval = setInterval(() => {
      timerLeft--;
      const el2 = document.getElementById('timerVal');
      if (el2) {
        el2.textContent = timerLeft;
        el2.classList.toggle('warning', timerLeft <= 10);
      }
      if (timerLeft <= 5 && timerLeft > 0) Audio.tick();
      if (timerLeft <= 0) {
        clearInterval(timerInterval);
        Audio.timeUp();
        setTimeout(() => {
          if (currentIndex < questions.length - 1) {
            currentIndex++;
            wsSelected = [];
            renderQuestion();
            startTimer();
          } else {
            showSummary();
          }
        }, 800);
      }
    }, 1000);
  }

  function resetTimer() {
    clearInterval(timerInterval);
    startTimer();
  }

  return {
    setData,
    start,
    answerQuiz,
    answerTF,
    checkFill,
    revealRiddle,
    revealMatching,
    toggleWS,
    next,
    prev,
    jump,
    setTimer,
  };

})();
