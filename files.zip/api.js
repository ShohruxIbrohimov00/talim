/* api.js – Backend API client */

const API_BASE = window.location.origin;

const Api = (() => {

  let _token = localStorage.getItem('edu_token') || null;

  function setToken(t) {
    _token = t;
    if (t) localStorage.setItem('edu_token', t);
    else localStorage.removeItem('edu_token');
  }

  function getToken() { return _token; }

  async function request(method, path, body = null) {
    const headers = { 'Content-Type': 'application/json' };
    if (_token) headers['Authorization'] = 'Bearer ' + _token;

    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    const res = await fetch(API_BASE + path, opts);

    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: 'Server xatosi' }));
      throw new Error(err.detail || 'Xato yuz berdi');
    }

    return res.json();
  }

  async function get(path) { return request('GET', path); }
  async function post(path, body) { return request('POST', path, body); }

  // ── Endpoints ──────────────────────────────────────────

  async function getFanlar() {
    return get('/api/fanlar');
  }

  async function getSinflar() {
    return get('/api/sinflar');
  }

  async function getMavzular(fan_id, sinf_id) {
    return get(`/api/mavzular?fan_id=${fan_id}&sinf_id=${sinf_id}`);
  }

  async function createMavzu(fan_id, sinf_id, nomi) {
    return post('/api/mavzular', { fan_id, sinf_id, nomi });
  }

  async function generate(data) {
    return post('/api/generate', data);
  }

  async function login(phone, password) {
    const res = await post('/api/auth/login', { phone, password });
    setToken(res.token);
    return res;
  }

  async function register(phone, name, password) {
    const res = await post('/api/auth/register', { phone, name, password });
    setToken(res.token);
    return res;
  }

  async function logout() {
    setToken(null);
  }

  async function me() {
    return get('/api/auth/me');
  }

  return {
    getFanlar,
    getSinflar,
    getMavzular,
    createMavzu,
    generate,
    login,
    register,
    logout,
    me,
    setToken,
    getToken
  };
})();
