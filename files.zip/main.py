"""
EduBoard Interactive – FastAPI Backend
Author: EduBoard Team
"""

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from contextlib import asynccontextmanager
import uvicorn
import json
import os

from database import engine, get_db, Base
from models import Fan, Sinf, Mavzu, GeneratedContent, User, Subscription
from schemas import (
    GenerateRequest, GenerateResponse,
    MavzuCreate, UserCreate, UserLogin,
    SubscriptionCreate
)
from services.ai_service import generate_with_ai, generate_sample_content
from services.auth_service import create_user, authenticate_user, create_token, get_current_user
from seed_data import seed_database

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    Base.metadata.create_all(bind=engine)
    db = next(get_db())
    seed_database(db)
    db.close()
    yield
    # Shutdown
    pass

app = FastAPI(
    title="EduBoard Interactive API",
    description="AI-powered interactive classroom board for Uzbek schools",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
app.mount("/static", StaticFiles(directory="../frontend/static"), name="static")
templates = Jinja2Templates(directory="../frontend/templates")


# ─── PAGES ────────────────────────────────────────────────────────────────────

@app.get("/")
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# ─── AUTH ENDPOINTS ───────────────────────────────────────────────────────────

@app.post("/api/auth/register")
async def register(data: UserCreate, db: Session = Depends(get_db)):
    user = create_user(db, data)
    token = create_token(user.id)
    return {"token": token, "user": {"id": user.id, "phone": user.phone, "name": user.name}}

@app.post("/api/auth/login")
async def login(data: UserLogin, db: Session = Depends(get_db)):
    user = authenticate_user(db, data.phone, data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Telefon yoki parol noto'g'ri")
    token = create_token(user.id)
    return {"token": token, "user": {"id": user.id, "phone": user.phone, "name": user.name}}

@app.get("/api/auth/me")
async def me(current_user = Depends(get_current_user)):
    return current_user


# ─── FANLAR ───────────────────────────────────────────────────────────────────

@app.get("/api/fanlar")
async def get_fanlar(db: Session = Depends(get_db)):
    fanlar = db.query(Fan).all()
    return [{"id": f.id, "nomi": f.nomi, "icon": f.icon, "rang": f.rang} for f in fanlar]


# ─── SINFLAR ──────────────────────────────────────────────────────────────────

@app.get("/api/sinflar")
async def get_sinflar(db: Session = Depends(get_db)):
    sinflar = db.query(Sinf).order_by(Sinf.raqami).all()
    return [{"id": s.id, "raqami": s.raqami} for s in sinflar]


# ─── MAVZULAR ─────────────────────────────────────────────────────────────────

@app.get("/api/mavzular")
async def get_mavzular(fan_id: int, sinf_id: int, db: Session = Depends(get_db)):
    mavzular = db.query(Mavzu).filter(
        Mavzu.fan_id == fan_id,
        Mavzu.sinf_id == sinf_id
    ).all()
    return [{"id": m.id, "nomi": m.nomi} for m in mavzular]

@app.post("/api/mavzular")
async def create_mavzu(data: MavzuCreate, db: Session = Depends(get_db)):
    existing = db.query(Mavzu).filter(
        Mavzu.fan_id == data.fan_id,
        Mavzu.sinf_id == data.sinf_id,
        Mavzu.nomi == data.nomi
    ).first()
    if existing:
        return {"id": existing.id, "nomi": existing.nomi}
    mavzu = Mavzu(fan_id=data.fan_id, sinf_id=data.sinf_id, nomi=data.nomi)
    db.add(mavzu)
    db.commit()
    db.refresh(mavzu)
    return {"id": mavzu.id, "nomi": mavzu.nomi}


# ─── GENERATE ─────────────────────────────────────────────────────────────────

@app.post("/api/generate")
async def generate(req: GenerateRequest, db: Session = Depends(get_db)):
    """
    Generate or retrieve exercise content.
    - If cached in DB → return immediately
    - If AI key provided → call OpenAI
    - Otherwise → return sample content
    """
    results = {}

    for mashq_turi in req.mashq_turlari:
        # Check cache
        cached = db.query(GeneratedContent).filter(
            GeneratedContent.mavzu_id == req.mavzu_id,
            GeneratedContent.mashq_turi == mashq_turi
        ).first()

        if cached and len(json.loads(cached.content) if isinstance(cached.content, str) else cached.content) >= req.necha_ta:
            content_data = cached.content if isinstance(cached.content, dict) else json.loads(cached.content)
            results[mashq_turi] = content_data[:req.necha_ta] if isinstance(content_data, list) else content_data
            continue

        # Generate new content
        if req.api_key:
            content = await generate_with_ai(
                api_key=req.api_key,
                fan=req.fan_nomi,
                sinf=req.sinf_raqami,
                mavzu=req.mavzu_nomi,
                mashq_turi=mashq_turi,
                necha_ta=req.necha_ta
            )
        else:
            content = generate_sample_content(
                fan=req.fan_nomi,
                mavzu=req.mavzu_nomi,
                mashq_turi=mashq_turi,
                necha_ta=req.necha_ta
            )

        # Save to DB
        if cached:
            cached.content = json.dumps(content, ensure_ascii=False)
            cached.necha_ta = req.necha_ta
        else:
            new_content = GeneratedContent(
                mavzu_id=req.mavzu_id,
                mashq_turi=mashq_turi,
                necha_ta=req.necha_ta,
                content=json.dumps(content, ensure_ascii=False)
            )
            db.add(new_content)

        db.commit()
        results[mashq_turi] = content

    return {"status": "ok", "data": results}


# ─── STATISTICS ───────────────────────────────────────────────────────────────

@app.get("/api/stats")
async def get_stats(db: Session = Depends(get_db)):
    total_generated = db.query(GeneratedContent).count()
    total_mavzular = db.query(Mavzu).count()
    total_fanlar = db.query(Fan).count()
    return {
        "total_generated": total_generated,
        "total_mavzular": total_mavzular,
        "total_fanlar": total_fanlar
    }


# ─── HEALTH ───────────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health():
    return {"status": "ok", "message": "EduBoard API ishlayapti ✅"}


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
