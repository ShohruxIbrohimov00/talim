"""
Authentication Service – JWT tokens, password hashing
"""

import os
import jwt
import hashlib
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session
from typing import Optional

from database import get_db
from models import User, Subscription
from schemas import UserCreate

SECRET_KEY = os.getenv("SECRET_KEY", "eduboard-secret-key-2024-uzbekistan")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_DAYS = 30
TRIAL_DAYS = 14


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(plain: str, hashed: str) -> bool:
    return hash_password(plain) == hashed


def create_token(user_id: int) -> str:
    expire = datetime.utcnow() + timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS)
    payload = {"sub": str(user_id), "exp": expire}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[int]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return int(payload["sub"])
    except Exception:
        return None


def create_user(db: Session, data: UserCreate) -> User:
    existing = db.query(User).filter(User.phone == data.phone).first()
    if existing:
        raise HTTPException(status_code=400, detail="Bu telefon raqam allaqachon ro'yxatdan o'tgan")

    user = User(
        phone=data.phone,
        name=data.name,
        hashed_password=hash_password(data.password)
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Create free trial subscription
    trial_end = datetime.utcnow() + timedelta(days=TRIAL_DAYS)
    sub = Subscription(
        user_id=user.id,
        plan="trial",
        is_active=True,
        trial_end=trial_end
    )
    db.add(sub)
    db.commit()

    return user


def authenticate_user(db: Session, phone: str, password: str) -> Optional[User]:
    user = db.query(User).filter(User.phone == phone).first()
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user


def get_current_user(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token taqdim etilmagan")

    token = authorization.replace("Bearer ", "")
    user_id = decode_token(token)
    if not user_id:
        raise HTTPException(status_code=401, detail="Noto'g'ri token")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="Foydalanuvchi topilmadi")

    return {"id": user.id, "phone": user.phone, "name": user.name}
