"""
Pydantic Schemas – Request / Response validation
"""

from pydantic import BaseModel, validator
from typing import List, Optional, Dict, Any


# ─── AUTH ─────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    phone: str
    name: str
    password: str

    @validator("phone")
    def phone_must_be_uzbek(cls, v):
        cleaned = v.replace("+", "").replace(" ", "").replace("-", "")
        if not cleaned.isdigit():
            raise ValueError("Telefon raqami faqat raqamlardan iborat bo'lishi kerak")
        return v

class UserLogin(BaseModel):
    phone: str
    password: str


# ─── CONTENT ──────────────────────────────────────────────────────────────────

class MavzuCreate(BaseModel):
    fan_id: int
    sinf_id: int
    nomi: str

class GenerateRequest(BaseModel):
    mavzu_id: int
    mavzu_nomi: str
    fan_nomi: str
    sinf_raqami: int
    mashq_turlari: List[str]
    necha_ta: int = 10
    api_key: Optional[str] = None

    @validator("mashq_turlari")
    def must_have_type(cls, v):
        allowed = {"quiz", "truefalse", "fill", "wordsearch", "riddle", "matching", "crossword", "memory", "drag"}
        for t in v:
            if t not in allowed:
                raise ValueError(f"Noto'g'ri mashq turi: {t}")
        return v

    @validator("necha_ta")
    def count_range(cls, v):
        if v < 3 or v > 30:
            raise ValueError("Savollar soni 3 dan 30 gacha bo'lishi kerak")
        return v

class GenerateResponse(BaseModel):
    status: str
    data: Dict[str, Any]


# ─── SUBSCRIPTION ─────────────────────────────────────────────────────────────

class SubscriptionCreate(BaseModel):
    user_id: int
    plan: str
    payment_token: Optional[str] = None
