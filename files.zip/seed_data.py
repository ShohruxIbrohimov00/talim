"""
Seed Data – Fanlar, Sinflar, Mavzular
"""

from sqlalchemy.orm import Session
from models import Fan, Sinf, Mavzu


FANLAR_DATA = [
    {"nomi": "Matematika",    "icon": "🔢", "rang": "#f59e0b"},
    {"nomi": "O'zbek tili",   "icon": "📝", "rang": "#10b981"},
    {"nomi": "Ingliz tili",   "icon": "🌍", "rang": "#3b82f6"},
    {"nomi": "Geografiya",    "icon": "🗺️", "rang": "#8b5cf6"},
    {"nomi": "Tarix",         "icon": "📜", "rang": "#ef4444"},
    {"nomi": "Fizika",        "icon": "⚡", "rang": "#f97316"},
    {"nomi": "Kimyo",         "icon": "🧪", "rang": "#06b6d4"},
    {"nomi": "Biologiya",     "icon": "🌿", "rang": "#84cc16"},
    {"nomi": "Boshqa",        "icon": "📖", "rang": "#94a3b8"},
]

MAVZULAR_DATA = {
    "Matematika": {
        1: ["Sonlar", "Qo'shish", "Ayirish", "Geometrik shakllar"],
        2: ["Ko'paytirish", "Bo'lish", "Jadval", "O'lchov birliklari"],
        3: ["Ko'p xonali sonlar", "Kasrlar kirish", "Vaqt o'lchovi", "Perimetr"],
        4: ["Oddiy kasrlar", "Aralash sonlar", "Maydon", "Koordinata"],
        5: ["Butun sonlar", "O'nli kasrlar", "Foizlar", "Geometrik shakllar"],
        6: ["Kasrlar", "Nisbat va proporsiya", "Tengsizliklar", "Koordinata o'qi"],
        7: ["Algebraik ifodalar", "Tenglamalar", "Ko'paytirish formulalari", "Uchburchaklar"],
        8: ["Kvadrat tenglamalar", "Funksiyalar", "Trigonometriya asoslari", "Vektorlar"],
        9: ["Funksiyalar grafigi", "Arifmetik progressiya", "Logarifm", "Trigonometriya"],
        10: ["Hosilalar", "Integral", "Kombinatorika", "Ehtimollar nazariyasi"],
        11: ["Limitlar", "Integral qo'llanilishi", "Statistika", "Kompleks sonlar"],
    },
    "O'zbek tili": {
        5: ["So'z turkumlari", "Ot", "Sifat", "Fe'l", "Imlo qoidalari"],
        6: ["Gapning bo'laklari", "Ega va kesim", "Ikkinchi darajali bo'laklar", "Murakkab gap"],
        7: ["So'z yasalishi", "Imlo qoidalari", "Badiiy adabiyot", "Matn tahlili"],
        8: ["Sintaksis", "Morfologiya", "Adabiy til me'yorlari", "Nutq uslublari"],
        9: ["Fonetika", "Leksikologiya", "Frazeologiya", "Stilistika"],
        10: ["Adabiyot tarixi", "She'riy san'atlar", "Dramaturgiya", "Publitsistika"],
        11: ["O'zbek adabiyoti tarixi", "Alisher Navoiy", "Zamonaviy adabiyot", "Tilshunoslik"],
    },
    "Ingliz tili": {
        5: ["Present Simple", "Colours & Numbers", "Family members", "Animals"],
        6: ["Past Simple", "Prepositions", "Countable & Uncountable", "Daily routines"],
        7: ["Present Perfect", "Comparatives & Superlatives", "Modal verbs", "Passive voice"],
        8: ["Conditionals", "Reported speech", "Relative clauses", "Future tenses"],
        9: ["Advanced Grammar", "Phrasal verbs", "Idioms & Expressions", "Essay writing"],
        10: ["Business English", "Academic writing", "Subjunctive mood", "Advanced vocabulary"],
        11: ["IELTS preparation", "Advanced grammar", "Literature", "Debate & discussion"],
    },
    "Fizika": {
        7: ["Mexanik harakat", "Kuch va massa", "Bosim", "Elektr asoslari"],
        8: ["Elektr toki", "Optika", "Issiqlik", "Magnit maydon"],
        9: ["Mexanika", "Dinamika", "Termodinamika", "Elektrodinamika"],
        10: ["Kvant fizikasi", "Atom tuzilishi", "Yadro fizikasi", "Optika"],
        11: ["Nisbiylik nazariyasi", "Kvant mexanikasi", "Astrofizika", "Fizika tarixi"],
    },
    "Kimyo": {
        8: ["Atom tuzilishi", "Kimyoviy bog'", "Oksidlanish-qaytarilish", "Kislotalar"],
        9: ["Organik kimyo", "Uglevodorodlar", "Spirtlar", "Karboksil kislotalar"],
        10: ["Polimer kimyo", "Mineral o'g'itlar", "Metallar kimyosi", "Elektroliz"],
        11: ["Analitik kimyo", "Sanoat kimyosi", "Ekologik kimyo", "Dori-darmon kimyosi"],
    },
    "Biologiya": {
        6: ["O'simlik hujayra", "Fotosintez", "O'simlik organlari", "Ekologiya"],
        7: ["Hayvonlar anatomiyasi", "Qon aylanishi", "Hazm qilish", "Asab tizimi"],
        8: ["Genetika asoslari", "Evolutsiya", "Ekosistema", "Bakteriyalar"],
        9: ["Hujayra biologiyasi", "Irsiyat", "Seleksiya", "Biotexnologiya"],
        10: ["Odam anatomiyasi", "Fiziologiya", "Immunologiya", "Ekologiya"],
        11: ["Molekulyar biologiya", "Genetika", "Biokimyo", "Evolyutsion biologiya"],
    },
    "Geografiya": {
        6: ["Materiklar", "Okeanlar", "Iqlim", "Tabiat zonalari"],
        7: ["O'zbekiston geografiyasi", "Aholishunoslik", "Sanoat", "Qishloq xo'jaligi"],
        8: ["Osiyo geografiyasi", "Yevropa", "Amerika", "Afrika"],
        9: ["Siyosiy geografiya", "Iqtisodiy geografiya", "Demografiya", "Globallashuv"],
        10: ["Geosiyosat", "Dunyo iqtisodiyoti", "Tabiat resurslari", "Ekologik muammolar"],
    },
    "Tarix": {
        5: ["Qadimgi dunyo", "Misр sivilizatsiyasi", "Gretsiya", "Rim imperiyasi"],
        6: ["O'rta asrlar", "Arab xalifaligi", "O'zbekiston tarixi", "Temuriylar"],
        7: ["Yangi davr", "Buyuk geografik kashfiyotlar", "Sanoat inqilobi", "Milliy harakatlar"],
        8: ["XX asr tarixi", "Birinchi jahon urushi", "Sovet davri", "Mustaqillik"],
        9: ["O'zbekiston mustaqilligi", "Zamonaviy tarix", "Xalqaro munosabatlar", "Globallashuv"],
    },
}


def seed_database(db: Session):
    """Seed the database with initial data"""

    # Check if already seeded
    if db.query(Fan).count() > 0:
        return

    print("🌱 Ma'lumotlar bazasi to'ldirilmoqda...")

    # Create subjects
    fan_map = {}
    for fan_data in FANLAR_DATA:
        fan = Fan(**fan_data)
        db.add(fan)
        db.flush()
        fan_map[fan_data["nomi"]] = fan.id

    # Create grades
    sinf_map = {}
    for raqami in range(1, 12):
        sinf = Sinf(raqami=raqami)
        db.add(sinf)
        db.flush()
        sinf_map[raqami] = sinf.id

    # Create topics
    for fan_nomi, sinflar in MAVZULAR_DATA.items():
        fan_id = fan_map.get(fan_nomi)
        if not fan_id:
            continue
        for sinf_raqami, mavzular in sinflar.items():
            sinf_id = sinf_map.get(sinf_raqami)
            if not sinf_id:
                continue
            for mavzu_nomi in mavzular:
                mavzu = Mavzu(fan_id=fan_id, sinf_id=sinf_id, nomi=mavzu_nomi)
                db.add(mavzu)

    db.commit()
    print("✅ Ma'lumotlar bazasi muvaffaqiyatli to'ldirildi!")
