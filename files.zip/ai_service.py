"""
AI Service – OpenAI GPT-4o-mini va sample content generator
"""

import json
import random
import string
import httpx
from typing import List, Dict, Any


# ─── OPENAI ───────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """Siz o'zbek maktab darsligi bo'yicha mutaxassis o'qituvchisiz.
Faqat sof JSON formatida javob bering. Hech qanday qo'shimcha matn, izoh yoki markdown yozmang.
Barcha savollar o'zbek tilida, maktab dasturiga mos va yosh bolalarga tushunarli bo'lsin."""

async def generate_with_ai(
    api_key: str,
    fan: str,
    sinf: int,
    mavzu: str,
    mashq_turi: str,
    necha_ta: int
) -> List[Dict]:
    """Call OpenAI API and return structured content"""

    prompt = build_prompt(fan, sinf, mavzu, mashq_turi, necha_ta)

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "gpt-4o-mini",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt}
                    ],
                    "temperature": 0.8,
                    "max_tokens": 4000
                }
            )

        if response.status_code != 200:
            # Fallback to sample
            return generate_sample_content(fan, mavzu, mashq_turi, necha_ta)

        data = response.json()
        text = data["choices"][0]["message"]["content"]

        # Clean JSON
        text = text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        text = text.strip().rstrip("```")

        parsed = json.loads(text)
        return parsed

    except Exception as e:
        print(f"AI Error: {e}")
        return generate_sample_content(fan, mavzu, mashq_turi, necha_ta)


def build_prompt(fan: str, sinf: int, mavzu: str, mashq_turi: str, necha_ta: int) -> str:
    formats = {
        "quiz": f"""[
  {{
    "savol": "Savol matni bu yerda",
    "variantlar": ["A variant", "B variant", "C variant", "D variant"],
    "togri_index": 0
  }}
]""",
        "truefalse": f"""[
  {{
    "savol": "Bu ibora to'g'rimi?",
    "javob": true
  }}
]""",
        "fill": f"""[
  {{
    "savol": "Gap bo'sh joy bilan: ___ + 2 = 5",
    "javob": "3"
  }}
]""",
        "wordsearch": f"""[
  {{
    "jadval": [
      ["K","A","S","R","X","B","V"],
      ["B","U","T","U","N","C","D"],
      ["S","U","R","A","T","E","F"],
      ["M","A","X","R","A","J","G"],
      ["S","O","N","H","I","J","K"],
      ["A","B","C","D","E","F","G"],
      ["H","I","J","K","L","M","N"]
    ],
    "sozlar": ["KASR", "BUTUN", "SURAT", "MAXRAJ", "SON"]
  }}
]""",
        "riddle": f"""[
  {{
    "savol": "Topishmoq matni?",
    "javob": "Javob"
  }}
]""",
        "matching": f"""[
  {{
    "sarlavha": "{mavzu} – moslashtirish",
    "juftlar": [
      {{"chap": "Chap element", "ong": "O'ng element"}},
      {{"chap": "Chap 2", "ong": "O'ng 2"}}
    ]
  }}
]"""
    }

    fmt = formats.get(mashq_turi, formats["quiz"])

    return f"""Fan: {fan}
Sinf: {sinf}
Mavzu: {mavzu}
Mashq turi: {mashq_turi}
Nechta: {necha_ta}

Yuqoridagi mashq turi uchun {necha_ta} ta savol yarating.
Faqat quyidagi JSON formatda qaytaring (boshqa hech narsa yozmang):

{fmt}

Eslatma: barcha savollar {fan} fanidan, {sinf}-sinf darajasida, mavzu: {mavzu}."""


# ─── SAMPLE CONTENT ───────────────────────────────────────────────────────────

MATH_QUIZ = [
    {"savol": "3/4 + 1/4 = ?", "variantlar": ["1", "1/2", "2/4", "4/4"], "togri_index": 0},
    {"savol": "5 × 8 = ?", "variantlar": ["40", "45", "35", "48"], "togri_index": 0},
    {"savol": "100 − 37 = ?", "variantlar": ["63", "73", "53", "67"], "togri_index": 0},
    {"savol": "2³ = ?", "variantlar": ["8", "6", "9", "4"], "togri_index": 0},
    {"savol": "√144 = ?", "variantlar": ["12", "11", "13", "14"], "togri_index": 0},
    {"savol": "15% of 200 = ?", "variantlar": ["30", "20", "25", "15"], "togri_index": 0},
    {"savol": "4² + 3² = ?", "variantlar": ["25", "20", "30", "15"], "togri_index": 0},
    {"savol": "180 ÷ 12 = ?", "variantlar": ["15", "14", "16", "18"], "togri_index": 0},
    {"savol": "0.5 + 0.75 = ?", "variantlar": ["1.25", "1.5", "1.0", "2.0"], "togri_index": 0},
    {"savol": "7 × 9 = ?", "variantlar": ["63", "56", "54", "72"], "togri_index": 0},
    {"savol": "48 ÷ 6 = ?", "variantlar": ["8", "7", "9", "6"], "togri_index": 0},
    {"savol": "3² × 2 = ?", "variantlar": ["18", "12", "16", "20"], "togri_index": 0},
]

ENG_QUIZ = [
    {"savol": "She ___ a doctor. (to be)", "variantlar": ["is", "are", "am", "be"], "togri_index": 0},
    {"savol": "They ___ football yesterday.", "variantlar": ["played", "play", "plays", "playing"], "togri_index": 0},
    {"savol": "I have ___ to Paris.", "variantlar": ["been", "went", "go", "gone"], "togri_index": 0},
    {"savol": "___ you speak English?", "variantlar": ["Can", "Is", "Are", "Do"], "togri_index": 0},
    {"savol": "He ___ every day.", "variantlar": ["runs", "run", "running", "ran"], "togri_index": 0},
    {"savol": "The book is ___ the table.", "variantlar": ["on", "in", "at", "by"], "togri_index": 0},
    {"savol": "What ___ your name?", "variantlar": ["is", "are", "am", "be"], "togri_index": 0},
    {"savol": "I ___ a student.", "variantlar": ["am", "is", "are", "be"], "togri_index": 0},
]

UZB_QUIZ = [
    {"savol": "Ot so'z turkumiga qaysi so'z kiradi?", "variantlar": ["kitob", "yashil", "yugur", "tez"], "togri_index": 0},
    {"savol": "Fe'l so'z turkumiga qaysi so'z kiradi?", "variantlar": ["o'qimoq", "katta", "uy", "yaxshi"], "togri_index": 0},
    {"savol": "Sifat so'z turkumiga qaysi so'z kiradi?", "variantlar": ["baland", "maktab", "bormoq", "u"], "togri_index": 0},
    {"savol": "Gapning egasi qaysi so'z turkumi bilan ifodalanadi?", "variantlar": ["Ot, olmosh", "Fe'l", "Sifat", "Ravish"], "togri_index": 0},
]

RIDDLES = [
    {"savol": "U doim to'la, lekin hech narsa ushlay olmaydi. Bu nima?", "javob": "Ko'z"},
    {"savol": "Qancha ko'p olib tashlasangiz, shuncha katta bo'ladi. Bu nima?", "javob": "Chuqur"},
    {"savol": "Og'zi bor, lekin gapirmaydi. Oyog'i bor, lekin yura olmaydi. Bu nima?", "javob": "Daryo"},
    {"savol": "Har kuni o'ladi, lekin har kech tiriladi. Bu nima?", "javob": "Oy"},
    {"savol": "Ular ko'p, lekin birdan ko'rasiz. Bu nima?", "javob": "Yulduzlar"},
    {"savol": "U suvda ham, quruqlikda ham yashaydi. Bu nima?", "javob": "Qurbaqa"},
    {"savol": "Tashida yeyiladi, ichida saqlanadi. Bu nima?", "javob": "Yong'oq"},
    {"savol": "Hamma ko'radi, lekin hech kim ushlay olmaydi. Bu nima?", "javob": "Nur (yorug'lik)"},
    {"savol": "Qancha issiq bo'lsa, shuncha tez yo'qoladi. Bu nima?", "javob": "Muz"},
    {"savol": "U sizda bor, lekin boshqalar uni ishlatadilar. Bu nima?", "javob": "Ismingiz"},
]

MATH_TRUEFALSE = [
    {"savol": "2 + 2 = 4", "javob": True},
    {"savol": "5 × 5 = 30", "javob": False},
    {"savol": "100 − 50 = 50", "javob": True},
    {"savol": "3² = 6", "javob": False},
    {"savol": "√25 = 5", "javob": True},
    {"savol": "10 ÷ 2 = 6", "javob": False},
    {"savol": "4 × 4 = 16", "javob": True},
    {"savol": "15 + 15 = 25", "javob": False},
    {"savol": "7 × 7 = 49", "javob": True},
    {"savol": "3/4 > 1/2", "javob": True},
]

MATH_FILL = [
    {"savol": "3 + ___ = 10", "javob": "7"},
    {"savol": "___ × 4 = 28", "javob": "7"},
    {"savol": "50 − ___ = 25", "javob": "25"},
    {"savol": "2³ = ___", "javob": "8"},
    {"savol": "√64 = ___", "javob": "8"},
    {"savol": "___ ÷ 6 = 7", "javob": "42"},
    {"savol": "5 × ___ = 45", "javob": "9"},
    {"savol": "100 − ___ = 37", "javob": "63"},
    {"savol": "___ + 28 = 50", "javob": "22"},
    {"savol": "4² = ___", "javob": "16"},
]

ENG_FILL = [
    {"savol": "She ___ a student.", "javob": "is"},
    {"savol": "They ___ football.", "javob": "play"},
    {"savol": "I ___ to school every day.", "javob": "go"},
    {"savol": "He ___ not here.", "javob": "is"},
    {"savol": "We ___ happy.", "javob": "are"},
    {"savol": "The cat ___ on the mat.", "javob": "is"},
    {"savol": "I ___ English.", "javob": "speak"},
    {"savol": "She ___ every morning.", "javob": "runs"},
]

MATH_MATCHING = [
    {"juftlar": [
        {"chap": "3 + 4", "ong": "7"},
        {"chap": "5 × 6", "ong": "30"},
        {"chap": "√25", "ong": "5"},
        {"chap": "2²", "ong": "4"},
        {"chap": "100 ÷ 10", "ong": "10"},
        {"chap": "15 − 8", "ong": "7"},
    ], "sarlavha": "Matematik ifodalarni moslashtiring"}
]

ENG_MATCHING = [
    {"juftlar": [
        {"chap": "apple", "ong": "olma"},
        {"chap": "book", "ong": "kitob"},
        {"chap": "school", "ong": "maktab"},
        {"chap": "water", "ong": "suv"},
        {"chap": "sun", "ong": "quyosh"},
        {"chap": "house", "ong": "uy"},
    ], "sarlavha": "Inglizcha so'zlarni o'zbekcha ma'nosiga moslashtiring"}
]


def generate_word_search(words: List[str] = None) -> Dict:
    """Generate a word search puzzle"""
    if not words:
        words = ["KASR", "BUTUN", "SURAT", "MAXRAJ", "SON", "RAQAM"]

    size = max(8, max(len(w) for w in words) + 2)
    grid = [[random.choice(string.ascii_uppercase) for _ in range(size)] for _ in range(size)]

    placed_words = []
    for word_idx, word in enumerate(words[:6]):
        # Place horizontally
        row = (word_idx * 2) % size
        col = random.randint(0, size - len(word))
        for j, ch in enumerate(word):
            if col + j < size:
                grid[row][col + j] = ch
        placed_words.append(word)

    return {
        "jadval": [list(row) for row in grid],
        "sozlar": placed_words
    }


def generate_sample_content(fan: str, mavzu: str, mashq_turi: str, necha_ta: int) -> Any:
    """Generate sample content based on subject"""

    fan_lower = fan.lower()

    if mashq_turi == "quiz":
        if "matematik" in fan_lower or "math" in fan_lower:
            pool = MATH_QUIZ
        elif "ingl" in fan_lower or "english" in fan_lower:
            pool = ENG_QUIZ
        elif "o'zbek" in fan_lower or "uzbek" in fan_lower:
            pool = UZB_QUIZ
        else:
            pool = MATH_QUIZ

        result = []
        for i in range(necha_ta):
            item = pool[i % len(pool)].copy()
            result.append(item)
        return result

    elif mashq_turi == "truefalse":
        pool = MATH_TRUEFALSE
        result = []
        for i in range(necha_ta):
            result.append(pool[i % len(pool)].copy())
        return result

    elif mashq_turi == "fill":
        if "ingl" in fan_lower or "english" in fan_lower:
            pool = ENG_FILL
        else:
            pool = MATH_FILL
        result = []
        for i in range(necha_ta):
            result.append(pool[i % len(pool)].copy())
        return result

    elif mashq_turi == "wordsearch":
        if "matematik" in fan_lower:
            words = ["KASR", "BUTUN", "SURAT", "MAXRAJ", "SON", "TENGLAMA"]
        elif "ingl" in fan_lower:
            words = ["APPLE", "BOOK", "SCHOOL", "WATER", "HOUSE", "TABLE"]
        elif "biologiy" in fan_lower:
            words = ["HUJAYRA", "YADRO", "TOMIR", "MEVA", "URUG"]
        elif "kimyo" in fan_lower:
            words = ["ATOM", "PROTON", "NEYTR", "ELEKTRON", "ION"]
        else:
            words = ["MAKTAB", "DARS", "KITOB", "QALAM", "DAFTAR"]
        return [generate_word_search(words)]

    elif mashq_turi == "riddle":
        riddles = random.sample(RIDDLES, min(necha_ta, len(RIDDLES)))
        while len(riddles) < necha_ta:
            riddles.append(random.choice(RIDDLES))
        return riddles[:necha_ta]

    elif mashq_turi == "matching":
        if "matematik" in fan_lower:
            return MATH_MATCHING
        elif "ingl" in fan_lower:
            return ENG_MATCHING
        else:
            return [{
                "sarlavha": f"{mavzu} – moslashtirish",
                "juftlar": [
                    {"chap": f"Element {i+1}", "ong": f"Javob {i+1}"}
                    for i in range(min(6, necha_ta))
                ]
            }]

    return []
