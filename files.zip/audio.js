/* audio.js – Web Audio API sound effects */

const Audio = (() => {
  let ctx = null;

  function getCtx() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    return ctx;
  }

  function playTone(freq, type, duration, volume = 0.3) {
    try {
      const c = getCtx();
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.connect(gain);
      gain.connect(c.destination);
      osc.type = type;
      osc.frequency.setValueAtTime(freq, c.currentTime);
      gain.gain.setValueAtTime(volume, c.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration);
      osc.start(c.currentTime);
      osc.stop(c.currentTime + duration);
    } catch(e) {}
  }

  function correct() {
    // Cheerful ascending ding
    try {
      const c = getCtx();
      const notes = [523, 659, 784, 1047]; // C5 E5 G5 C6
      notes.forEach((freq, i) => {
        const osc = c.createOscillator();
        const gain = c.createGain();
        osc.connect(gain);
        gain.connect(c.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, c.currentTime + i * 0.1);
        gain.gain.setValueAtTime(0, c.currentTime + i * 0.1);
        gain.gain.linearRampToValueAtTime(0.3, c.currentTime + i * 0.1 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + i * 0.1 + 0.3);
        osc.start(c.currentTime + i * 0.1);
        osc.stop(c.currentTime + i * 0.1 + 0.35);
      });
    } catch(e) {}
  }

  function wrong() {
    // Low buzzing wrong sound
    try {
      const c = getCtx();
      [200, 180, 160].forEach((freq, i) => {
        const osc = c.createOscillator();
        const gain = c.createGain();
        osc.connect(gain);
        gain.connect(c.destination);
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, c.currentTime + i * 0.09);
        gain.gain.setValueAtTime(0.18, c.currentTime + i * 0.09);
        gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + i * 0.09 + 0.25);
        osc.start(c.currentTime + i * 0.09);
        osc.stop(c.currentTime + i * 0.09 + 0.28);
      });
    } catch(e) {}
  }

  function timeUp() {
    // Alert beep
    playTone(880, 'square', 0.3, 0.15);
  }

  function tick() {
    // Soft click
    playTone(1200, 'sine', 0.05, 0.08);
  }

  function reveal() {
    // Magical reveal sound
    try {
      const c = getCtx();
      [392, 523, 659, 784, 1047].forEach((freq, i) => {
        const osc = c.createOscillator();
        const gain = c.createGain();
        osc.connect(gain);
        gain.connect(c.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, c.currentTime + i * 0.08);
        gain.gain.setValueAtTime(0.2, c.currentTime + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + i * 0.08 + 0.4);
        osc.start(c.currentTime + i * 0.08);
        osc.stop(c.currentTime + i * 0.08 + 0.45);
      });
    } catch(e) {}
  }

  return { correct, wrong, timeUp, tick, reveal };
})();
